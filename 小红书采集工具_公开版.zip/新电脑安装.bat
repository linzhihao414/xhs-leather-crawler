@echo off
chcp 65001 >nul
title 新电脑一键安装环境
cd /d "%~dp0"
echo ============================================
echo   新电脑一键安装运行环境
echo   需要已安装 Python 3.11+
echo   自动创建 .venv 并安装全部依赖
echo ============================================
echo.
echo [1/4] 检查 Python ...
python --version
if errorlevel 1 (
    echo [错误] 未检测到 Python，请先到 python.org 安装 Python 3.11+
    pause
    exit /b
)
echo.
echo [2/4] 创建虚拟环境并安装依赖 ...
python -m venv .venv
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
echo.
echo [3/4] 安装 Playwright 浏览器 ...
if exist "browsers\chromium-1228" (
    echo 检测到包内已自带浏览器，直接复制到系统目录（无需联网下载）...
    if not exist "%LOCALAPPDATA%\ms-playwright" mkdir "%LOCALAPPDATA%\ms-playwright"
    xcopy /e /i /y "browsers\chromium-1228" "%LOCALAPPDATA%\ms-playwright\chromium-1228" >nul
    if exist "browsers\chromium_headless_shell-1228" xcopy /e /i /y "browsers\chromium_headless_shell-1228" "%LOCALAPPDATA%\ms-playwright\chromium_headless_shell-1228" >nul
    echo ✅ 浏览器组件已就位
) else (
    echo 包内无浏览器组件，尝试联网下载...
    ".venv\Scripts\python.exe" -m playwright install chromium
)
echo.
echo [4/4] 验证安装 ...
".venv\Scripts\python.exe" -c "from playwright.sync_api import sync_playwright; p=sync_playwright().start(); b=p.chromium.launch(); print('浏览器启动成功!'); b.close(); p.stop()"
if errorlevel 1 (
    echo [警告] 浏览器验证未通过，请检查上方错误
    pause
    exit /b
)
echo.
echo ✅ 环境安装完成！可以双击 1_一键爬取并导出.bat 开始使用
pause

@echo off
chcp 65001 >nul
title 小红书导出Excel
cd /d "%~dp0"
echo ============================================
echo   小红书 数据转 Excel（仅导出，不爬取）
echo ============================================
echo.
if not exist ".venv\Scripts\python.exe" (
    echo [错误] 未找到 python 虚拟环境，请先运行 新电脑安装.bat
    pause
    exit /b
)
echo [1/2] 转换 jsonl 为 Excel ...
".venv\Scripts\python.exe" export_to_excel.py
echo.
echo [2/2] 复制最新 Excel 到 导出结果 文件夹 ...
if not exist "导出结果" mkdir "导出结果"
for /f "delims=" %%i in ('dir /b /o-d "data\xhs\*.xlsx" 2^>nul') do (
    copy /y "data\xhs\%%i" "导出结果\小红书数据_最新.xlsx" >nul
    echo 已复制: %%i
    goto done
)
:done
echo.
echo ✅ 导出完成！正在打开 导出结果 文件夹...
start "" "导出结果"
pause

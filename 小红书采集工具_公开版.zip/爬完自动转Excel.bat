@echo off
rem ============================================
rem  One-click: crawl XHS then auto-export Excel
rem  1) Run crawler (platform/type/keys from config)
rem  2) Convert latest jsonl to data/xhs/*.xlsx
rem  Prereq: Chrome remote debugging ON
rem  (chrome://inspect/#remote-debugging -> Allow)
rem ============================================
cd /d "%~dp0"
echo [1/2] Running crawler: XHS / qrcode login / search ...
".venv\Scripts\python.exe" main.py --platform xhs --lt qrcode --type search
echo [2/2] Converting jsonl to Excel ...
".venv\Scripts\python.exe" export_to_excel.py
pause

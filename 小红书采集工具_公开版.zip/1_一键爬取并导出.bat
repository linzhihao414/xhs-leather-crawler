@echo off
chcp 65001 >nul
title 小红书一键爬取并导出
cd /d "%~dp0"
echo ============================================
echo   小红书一键爬取 + 导出 Excel
echo   流程: 扫码登录 → 按关键词爬取 → 转Excel → 复制到导出结果
echo ============================================
echo.
if not exist ".venv\Scripts\python.exe" (
    echo [错误] 未找到 python 虚拟环境，请先运行 新电脑安装.bat
    pause
    exit /b
)
echo [1/3] 开始爬取小红书（弹窗扫码登录）...
".venv\Scripts\python.exe" main.py --platform xhs --lt qrcode --type search
echo.
echo [2/3] 转换 jsonl 为 Excel ...
".venv\Scripts\python.exe" export_to_excel.py
echo.
echo [3/3] 复制最新 Excel 到 导出结果 文件夹 ...
if not exist "导出结果" mkdir "导出结果"
for /f "delims=" %%i in ('dir /b /o-d "data\xhs\*.xlsx" 2^>nul') do (
    copy /y "data\xhs\%%i" "导出结果\小红书数据_最新.xlsx" >nul
    echo 已复制: %%i
    goto done
)
:done
echo.
echo ✅ 全部完成！结果在 导出结果 文件夹，正在打开...
start "" "导出结果"
pause

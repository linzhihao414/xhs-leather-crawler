@echo off
rem ============================================
rem  MediaCrawler XHS data -> Excel one-click export
rem  Double-click to convert the latest day's jsonl
rem  into data/xhs/xiaohongshu_data_<date>.xlsx
rem  For a specific date: py export_to_excel.py 2026-09-24
rem ============================================
cd /d "%~dp0"
py export_to_excel.py %1
pause

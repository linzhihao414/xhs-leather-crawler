@echo off
chcp 65001 >nul
title 小红书关键词修改
cd /d "%~dp0"
echo ============================================
echo   小红书关键词修改工具
echo ============================================
echo.
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" "tools\keywords_editor.py"
) else if exist "tools\keywords_editor.py" (
    python "tools\keywords_editor.py"
) else (
    echo 未找到 python 环境，请先运行 新电脑安装.bat
    pause
    exit /b
)

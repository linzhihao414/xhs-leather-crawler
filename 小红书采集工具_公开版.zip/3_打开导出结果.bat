@echo off
chcp 65001 >nul
title 打开导出结果
cd /d "%~dp0"
if not exist "导出结果" mkdir "导出结果"
start "" "导出结果"

# -*- coding: utf-8 -*-
# Copyright (c) 2025 relakkes@gmail.com
#
# This file is part of MediaCrawler project.
# Repository: https://github.com/NanmiCoder/MediaCrawler/blob/main/model/m_baidu_tieba.py
# GitHub: https://github.com/NanmiCoder
# Licensed under NON-COMMERCIAL LEARNING LICENSE 1.1
#

# 声明：本代码仅供学习和研究目的使用。使用者应遵守以下原则：
# 1. 不得用于任何商业用途。
# 2. 使用时应遵守目标平台的使用条款和robots.txt规则。
# 3. 不得进行大规模爬取或对平台造成运营干扰。
# 4. 应合理控制请求频率，避免给目标平台带来不必要的负担。
# 5. 不得用于任何非法或不当的用途。
#
# 详细许可条款请参阅项目根目录下的LICENSE文件。
# 使用本代码即表示您同意遵守上述原则和LICENSE中的所有条款。


# -*- coding: utf-8 -*-
from typing import Optional

from pydantic import BaseModel, Field


class TiebaNote(BaseModel):
    """
    Baidu Tieba post
    """
    note_id: str = Field(..., description="Post ID")
    title: str = Field(..., description="Post title")
    desc: str = Field(default="", description="Post description")
    note_url: str = Field(..., description="Post link")
    publish_time: str = Field(default="", description="Publish time")
    creator_hash: str = Field(default="", description="创作者匿名哈希(不存原始用户链接)")
    user_nickname: str = Field(default="", description="User nickname (已脱敏)")
    tieba_name: str = Field(..., description="Tieba name")
    tieba_link: str = Field(..., description="Tieba link")
    total_replay_num: int = Field(default=0, description="Total reply count")
    total_replay_page: int = Field(default=0, description="Total reply pages")
    source_keyword: str = Field(default="", description="Source keyword")


class TiebaComment(BaseModel):
    """
    Baidu Tieba comment
    """

    comment_id: str = Field(..., description="Comment ID")
    parent_comment_id: str = Field(default="", description="Parent comment ID")
    content: str = Field(..., description="Comment content")
    creator_hash: str = Field(default="", description="创作者匿名哈希(不存原始用户链接)")
    user_nickname: str = Field(default="", description="User nickname (已脱敏)")
    publish_time: str = Field(default="", description="Publish time")
    sub_comment_count: int = Field(default=0, description="Sub-comment count")
    note_id: str = Field(..., description="Post ID")
    note_url: str = Field(..., description="Post link")
    tieba_id: str = Field(..., description="Tieba ID")
    tieba_name: str = Field(..., description="Tieba name")
    tieba_link: str = Field(..., description="Tieba link")


class TiebaCreator(BaseModel):
    """
    Baidu Tieba creator（教学版：个人资料不再落库，仅作内存对象）
    """
    creator_hash: str = Field(default="", description="创作者匿名哈希(不存原始用户链接)")
    user_nickname: str = Field(default="", description="User nickname (已脱敏)")
    follows: int = Field(default=0, description="Follows count")
    fans: int = Field(default=0, description="Fans count")
    registration_duration: str = Field(default="", description="Registration duration")
